﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Miljöbrott_final.Controllers
{
  public class CitizenController : Controller
  {
    //Metod för att visa vyner 
    public ViewResult Services()
    {
      return View();
    }

    public ViewResult Faq()
    {
      return View();
    }

    public ViewResult Contact()
    {
      return View();
    }

    public ViewResult Validate()
    {
      return View();
    }
    public ViewResult Thanks()
    {
      return View();
    }
  }
 }


